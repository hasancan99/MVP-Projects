"""Checkpoint 2 Classes"""
import math as m
import numpy as np
import matplotlib.pyplot as plt
import copy 


#----------------------------------------------------------------------------------------------------------------------------------

class RulesGoL(object):
    def __init__(self, a_s):
        
        self.a_s=a_s
    
#----------------------------------------------------------------------------------------------------------------------------------
    def sumArray(self, i, j, array):
        #newArray=array
        #newArray=self.array
        neighbourSum=0
        for h in range(-1,2):
            for k in range(-1,2):
                if h == 0 and k ==0 :
                    pass
                else:
                    
                    a=(i+h)%self.a_s
                    b=(j+k)%self.a_s
                    neighbourSum+=array[a][b]
        
        return neighbourSum
        
#----------------------------------------------------------------------------------------------------------------------------------
    def allRules(self, array):
        nextArray=np.zeros((self.a_s,self.a_s))
        for i in range (0,self.a_s):
            for j in range(0,self.a_s):
                neighbourSum=self.sumArray(i, j, array)
                if array[i][j]==1:
                    #print(neighbourSum)
                    if neighbourSum<2:
                        nextArray[i][j]=0
                    if neighbourSum>3:
                        nextArray[i][j]=0
                    
                    if neighbourSum==3 or neighbourSum==2:
                        nextArray[i][j]=1
                else:
                    if neighbourSum == 3:
                        nextArray[i][j]=1
        #print("first iter")
        #print(array)
        #print("Second iter")
        #print(nextArray)
        return nextArray
    
    def newArrayget(self,array):
        """This function sets a copy of the changing array and to optimise it also uses the same for loops to 
        work out number of active sites"""
        array=self.allRules(array)
        arraysum=0     #sums of the number of active sites
        #print(array)
        for i in range(0,self.a_s):
            for j in range(0,self.a_s):
                self.arrayChange[i][j]=array[i][j]
                arraysum+=array[i][j]
        #print(arraysum)
        return self.arrayChange,arraysum
    
    def interate(self,array,steps):
        self.arrayChange=np.zeros((self.a_s,self.a_s))
        self.arraysum=np.zeros(steps)
        for i in range (0,steps):
            array,arraysum=self.newArrayget(array)
            self.animate(self.arrayChange)
            
                
            
    def animate(self, array):
        f=open('GameofLife.dat','w')
        for i in range(self.a_s):
            for j in range(self.a_s):
                f.write('%d %d %lf\n'%(i,j,array[i,j]))
        f.close()
        plt.cla()
        im=plt.imshow(array, animated=True)
        plt.draw()
        plt.pause(0.01) 
    
    #def sumTotalArray(self,array):
    
    
    def equilibriums(self,steps):
        
        times=np.zeros(100)
        for k in range (0,100):
            print("Runs = ")
            print(k+1)
            array=np.random.choice([1,0], [self.a_s,self.a_s],[0.5,0.5])
            self.arrayChange=np.zeros((self.a_s,self.a_s))
            self.arraysum=np.zeros(steps)
            for i in range (0,steps):
                array,arraysum=self.newArrayget(array)
                self.arraysum[i]=arraysum
                if self.arraysum[i]==self.arraysum[i-2] and self.arraysum[i]==self.arraysum[i-1] and self.arraysum[i]==self.arraysum[i-3] and self.arraysum[i]==self.arraysum[i-4]:
                    print("Equilibrium reached!")
                    print(i)
                    times[k]=i
                    break
        return times        

    def newArraywithCoM(self,array):
        """This function sets a copy of the changing array and to optimise it also uses the same for loops to 
        work out the centre of mass sum"""
        array=self.allRules(array)
        CoMx=0
        CoMy=0
        #print(array)
        for i in range(0,self.a_s):
            for j in range(0,self.a_s):
                self.arrayChange[i][j]=array[i][j]
                if array[i][j]==1:
                    if 5<i>44 or 5<j>44:  
                        print("HI")
                        CoMx+= i
                        CoMy+= j
        CoMxTot=CoMx/5
        CoMyTot=CoMy/5
                    
        #print(CoMxTot)
        #print(CoMyTot)
        #print(arraysum)
        return self.arrayChange,CoMxTot,CoMyTot
        

    def centreOfmass(self,array,steps):
        self.arrayChange=np.zeros((self.a_s,self.a_s))
        CentreOfMassXY=np.zeros((2,steps))
        #print(CentreOfMassXY)
        self.arraysum=np.zeros(steps)
        for i in range (0,steps):
            array,CentreOfMassXY[0][i],CentreOfMassXY[1][i]=self.newArraywithCoM(array)
            print(CentreOfMassXY[0][i],CentreOfMassXY[1][i])
            #self.animate(self.arrayChange)       
        return CentreOfMassXY             
                    
        
